package com.dicoding.picodiploma.loginwithanimation.data

import com.dicoding.picodiploma.loginwithanimation.data.api.ApiConfig
import com.dicoding.picodiploma.loginwithanimation.data.api.ApiService
import com.dicoding.picodiploma.loginwithanimation.data.pref.UserModel
import com.dicoding.picodiploma.loginwithanimation.data.pref.UserPreference
import com.dicoding.picodiploma.loginwithanimation.data.response.LoginResponse
import com.dicoding.picodiploma.loginwithanimation.data.response.RegisterResponse
import com.dicoding.picodiploma.loginwithanimation.data.response.StoryResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import retrofit2.Response

class UserRepository(private val apiService: ApiService, private val userPreference: UserPreference) {


    suspend fun login(email: String, password: String): Response<LoginResponse> {
        return withContext(Dispatchers.IO) {
            apiService.login(email, password)
        }
    }


    suspend fun registerUser(name: String, email: String, password: String): RegisterResponse {
        return withContext(Dispatchers.IO) {
            apiService.register(name, email, password)
        }
    }

//    suspend fun getStoryList(token: String): StoryResponse {
//        return withContext(Dispatchers.IO) {
//            val apiService = ApiConfig.getApiService(token)
//            val response: Response<StoryResponse> = apiService.getStories(token)
//            if (response.isSuccessful) {
//                val storyResponse = response.body()
//                storyResponse ?: StoryResponse(listStory = emptyList(), error = true, message = "No data available")
//            } else {
//                throw Exception("Failed to fetch stories: ${response.message()}")
//            }
//        }
//    }

    suspend fun getStoryList(token: String) : StoryResponse {
        return apiService.getStories(token)
    }




    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }


    fun getSession(): Flow<UserModel> {
        return userPreference.getSession()
    }

    companion object {
        @Volatile
        private var instance: UserRepository? = null


        fun getInstance(apiService: ApiService, userPreference: UserPreference): UserRepository {
            return instance ?: synchronized(this) {
                val newInstance = UserRepository(apiService, userPreference)
                instance = newInstance
                newInstance
            }
        }
    }
}
