package com.dicoding.picodiploma.loginwithanimation.view.signup
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.picodiploma.loginwithanimation.data.UserRepository
import com.dicoding.picodiploma.loginwithanimation.data.response.RegisterResponse
import kotlinx.coroutines.launch

class RegisterViewModel(private val userRepository: UserRepository) : ViewModel() {

    fun registerUser(
        name: String,
        email: String,
        password: String,
        onSuccess: (RegisterResponse) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val response = userRepository.registerUser(name, email, password)
                onSuccess(response)
            } catch (e: Exception) {
                onError(e)
            }
        }
    }
}
