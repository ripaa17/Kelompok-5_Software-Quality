package com.dicoding.picodiploma.loginwithanimation.view.story

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.loginwithanimation.R
import com.dicoding.picodiploma.loginwithanimation.databinding.FragmentStoryListBinding
import com.dicoding.picodiploma.loginwithanimation.view.ViewModelFactory
import com.dicoding.picodiploma.loginwithanimation.view.adapter.StoryAdapter


class StoryListFragment : Fragment() {

    private var _binding: FragmentStoryListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: StoryViewModel by viewModels {
        ViewModelFactory.getInstance(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStoryListBinding.inflate(inflater, container, false)
        return binding.root // Mengembalikan view dari binding
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val token = arguments?.getString("TOKEN") ?: ""

        if (token.isNotEmpty()) {
            viewModel.getStories("Bearer $token")
        } else {
            Toast.makeText(context, "Token is missing", Toast.LENGTH_SHORT).show()
            return // Keluar jika token tidak tersedia
        }

        // Observe story list and update UI
        viewModel.storyList.observe(viewLifecycleOwner) { stories ->
            if (!stories.isNullOrEmpty()) {
                binding.rvStories.apply {
                    layoutManager = LinearLayoutManager(context)
                    adapter = StoryAdapter(stories)
                }
            } else {
                Toast.makeText(context, "No stories available", Toast.LENGTH_SHORT).show()
            }
        }

        // Observe loading state to show or hide progress bar
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        // Observe error message and show it if any
        viewModel.errorMessage.observe(viewLifecycleOwner) { errorMessage ->
            errorMessage?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

